# Icon files needed

For Chrome Web Store publishing, convert `icon.svg` to PNGs:

```bash
# If you have ImageMagick installed:
convert -background none -resize 16x16  icon.svg icon16.png
convert -background none -resize 48x48  icon.svg icon48.png
convert -background none -resize 128x128 icon.svg icon128.png
```

Or use any online SVG→PNG converter at the three sizes above.

For LOCAL developer-mode install testing, the extension will still work — Chrome shows a default icon when PNG files are missing.
