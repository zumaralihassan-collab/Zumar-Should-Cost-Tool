/* Should Cost AI — Gmail / Outlook Content Script
 * Scans the opened email for supplier quote data (price, qty, lead time)
 * and overlays a Should Cost AI analysis panel.
 * Author: Mohammed Zumar Ali Hassan
 */
(function(){
  const SHOULD_COST_TOOL_URL = 'https://zumaralihassan-collab.github.io/Zumar-Should-Cost-Tool/';
  const PRICE_REGEX = /(?:USD|US\$|\$|€|£|₹|INR|EUR|GBP|Rs\.?|\bunit price\b|\bprice\b)[^\d]{0,15}(\d[\d,]*(?:\.\d+)?)/gi;
  const QTY_REGEX = /(?:qty|quantity|units?|pcs?|pieces?)[^\d]{0,8}(\d[\d,]*)/gi;
  const LEAD_REGEX = /(?:lead\s*time|delivery|ship(?:ment)?\s*in)[^\d]{0,8}(\d+)\s*(days?|weeks?|months?)/gi;
  const PAYMENT_REGEX = /(?:payment\s*terms?|NET\s*)(\d+)\s*(days?)/gi;
  function extractFromText(text){
    const result = { prices: [], quantities: [], leadTimes: [], paymentTerms: [] };
    let m;
    while((m = PRICE_REGEX.exec(text)) !== null) result.prices.push(parseFloat(m[1].replace(/,/g,'')));
    while((m = QTY_REGEX.exec(text)) !== null) result.quantities.push(parseInt(m[1].replace(/,/g,'')));
    while((m = LEAD_REGEX.exec(text)) !== null) result.leadTimes.push(m[1]+' '+m[2]);
    while((m = PAYMENT_REGEX.exec(text)) !== null) result.paymentTerms.push(m[1]+' days');
    return result;
  }
  function findEmailBody(){
    // Gmail
    let body = document.querySelector('.adn .ii .a3s, .a3s.aiL');
    if(body) return body;
    // Outlook web
    body = document.querySelector('[role="document"] .ReadingPaneContent, .rps_4f95, .allowTextSelection');
    if(body) return body;
    return null;
  }
  function createPanel(extracted){
    if(document.getElementById('scAiPanel')) return;
    const panel = document.createElement('div');
    panel.id = 'scAiPanel';
    panel.className = 'sc-ai-panel';
    panel.innerHTML = `
      <div class="sc-ai-header">
        <span class="sc-ai-badge">SC</span>
        <span class="sc-ai-title">Should Cost AI</span>
        <button class="sc-ai-close" title="Close">×</button>
      </div>
      <div class="sc-ai-body">
        <div class="sc-ai-section">
          <div class="sc-ai-label">📦 Detected from email</div>
          <div class="sc-ai-data">
            <div><b>Prices:</b> ${extracted.prices.length ? extracted.prices.slice(0,3).map(p=>p.toLocaleString()).join(', ') : '—'}</div>
            <div><b>Quantities:</b> ${extracted.quantities.length ? extracted.quantities.slice(0,3).map(q=>q.toLocaleString()).join(', ') : '—'}</div>
            <div><b>Lead time:</b> ${extracted.leadTimes.length ? extracted.leadTimes[0] : '—'}</div>
            <div><b>Payment terms:</b> ${extracted.paymentTerms.length ? extracted.paymentTerms[0] : '—'}</div>
          </div>
        </div>
        <div class="sc-ai-actions">
          <button id="scAiAnalyze" class="sc-ai-btn-primary">Analyze in Should Cost AI →</button>
          <button id="scAiCopy" class="sc-ai-btn-secondary">Copy as RFQ row</button>
        </div>
        <div class="sc-ai-footer">© Mohammed Zumar Ali Hassan</div>
      </div>
    `;
    document.body.appendChild(panel);
    panel.querySelector('.sc-ai-close').onclick = () => panel.remove();
    panel.querySelector('#scAiAnalyze').onclick = () => {
      const url = SHOULD_COST_TOOL_URL + '#rfq';
      window.open(url, '_blank');
    };
    panel.querySelector('#scAiCopy').onclick = () => {
      const supplierGuess = guessSupplierFromEmail() || 'Supplier';
      const p = extracted.prices[0] || '';
      const q = extracted.quantities[0] || '';
      const lt = (extracted.leadTimes[0] || '').match(/\d+/)?.[0] || '';
      const pt = (extracted.paymentTerms[0] || '').match(/\d+/)?.[0] || '';
      const row = [supplierGuess, '', q, p, q*p, 'USD', '', lt, pt, 30, 'No', 'Extracted by SC AI extension'].join('\t');
      navigator.clipboard.writeText(row).then(()=>{
        const btn = panel.querySelector('#scAiCopy');
        btn.textContent = '✓ Copied to clipboard';
        setTimeout(()=>{ btn.textContent='Copy as RFQ row'; }, 2000);
      });
    };
  }
  function guessSupplierFromEmail(){
    // Try Gmail "From" header
    const from = document.querySelector('.gD, .go .gD');
    return from?.getAttribute('email')?.split('@')[1]?.split('.')[0] || from?.textContent || null;
  }
  function scan(){
    const body = findEmailBody();
    if(!body) return;
    const text = body.innerText || body.textContent || '';
    // Reset lastIndex on global regexes
    PRICE_REGEX.lastIndex = 0; QTY_REGEX.lastIndex = 0; LEAD_REGEX.lastIndex = 0; PAYMENT_REGEX.lastIndex = 0;
    const extracted = extractFromText(text);
    // Only show panel if we found at least 2 procurement signals
    const signalCount = extracted.prices.length + extracted.quantities.length + extracted.leadTimes.length;
    if(signalCount >= 2) createPanel(extracted);
  }
  // Watch for email-view changes (Gmail uses History API and DOM mutations)
  const observer = new MutationObserver(()=>{
    document.getElementById('scAiPanel')?.remove();
    setTimeout(scan, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  setTimeout(scan, 1500);
})();
