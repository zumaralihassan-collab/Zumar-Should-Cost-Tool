# Should Cost AI — Browser Extension

A Chrome/Edge extension that overlays Should Cost AI inline in Gmail and Outlook supplier emails.

## What it does

Open any supplier quote email — the extension auto-detects:
- Unit prices (₹, $, €, £)
- Order quantities
- Lead times (days / weeks)
- Payment terms (NET 30, NET 45, etc.)

A floating panel appears top-right of the email with:
- All extracted procurement signals
- **"Analyze in Should Cost AI"** — opens the full tool with this data pre-filled
- **"Copy as RFQ row"** — tab-separated string ready to paste into the RFQ template Excel

## Install (developer mode)

1. Open Chrome / Edge → `chrome://extensions/` (or `edge://extensions/`)
2. Toggle **Developer mode** (top-right)
3. Click **"Load unpacked"**
4. Select this `extension/` folder
5. Pin the Should Cost AI icon to your toolbar

The extension activates automatically when you open Gmail or Outlook Web.

## Permissions explained

- `mail.google.com`, `outlook.live.com`, `outlook.office.com` — content script runs only on these domains
- `storage` — saves your preferences locally (no remote sync)
- `activeTab` — required to read the open email's text

The extension **never sends data anywhere** — all processing is local in the browser.

## Publishing to Chrome Web Store

To publish:
1. Generate `icon16.png`, `icon48.png`, `icon128.png` (Should Cost AI brand mark)
2. Zip the `extension/` folder
3. Upload to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole) (one-time $5 fee)
4. Submit for review (typically 1–3 business days)

## Built by

**Mohammed Zumar Ali Hassan**
MS Supply Chain Management (STEM), UT Dallas
[linkedin.com/in/zumarali15](https://linkedin.com/in/zumarali15)
