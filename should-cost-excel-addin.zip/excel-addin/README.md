# Should Cost AI — Excel Add-in

Real-time should-cost analysis directly inside Excel.

## What it does

Edit any cell in your Excel spreadsheet — the Should Cost AI add-in detects the change, runs the should-cost engine, and **writes the result back to Excel** automatically. No buttons, no refresh — true bi-directional real-time sync.

## Demo

```
A                    B
─────────────────────────────────────
Product              copper conductor   ← edit this
Quantity             10000              ← or this
Region               china              ← or this

Should-Cost          $864.06            ← auto-updates
```

## Install (sideload — for testing)

### Excel Desktop on Mac/Windows

1. Download `manifest.xml` from this folder
2. Open Excel
3. Insert → My Add-ins → Manage My Add-ins → Upload My Add-in
4. Browse to `manifest.xml`
5. Click "Upload"
6. The Should Cost AI button appears on the Home ribbon

### Excel Online (Office 365)

1. Open any Excel file in browser
2. Insert → Add-ins → Upload My Add-in
3. Browse to `manifest.xml`
4. The taskpane appears on the right

## Usage

1. Click "Show Should Cost" in the ribbon → taskpane opens
2. Click "📋 Insert sample template" — fills A1:B6 with a working demo
3. Click "▶ Start Real-time Sync"
4. Now edit the product name (B2) — the should-cost in B6 updates instantly

## Custom mapping

Don't want the sample layout? Specify your own cells:

- **Product cell** — where the product name lives (e.g. `D5`)
- **Quantity cell** — order quantity (e.g. `E5`)
- **Region cell** — sourcing region (e.g. `F5`)
- **Result cell** — where should-cost gets written (e.g. `G5`)

The add-in watches all those cells. Any change → recalculation → write-back.

## Supported product keywords

Type any product name containing these keywords:

- `brick` → red sand brick template
- `perfume` → EdT 50ml template
- `t-shirt` / `tshirt` → cotton T-shirt template
- `conductor` / `cable` → copper conductor template
- `bottle` → PET bottle template
- `battery` → Li-ion cell template

(For the full 20-template library, use the standalone tool at the URL below.)

## Production deployment

For organization-wide deployment via Microsoft 365 Admin Center:

1. Validate manifest at [Office Add-in Validator](https://github.com/OfficeDev/office-addin-validator)
2. Submit to your IT admin for Microsoft 365 sideload OR
3. Submit to the public Office Store ($99/year + review)

## Tech stack

- **Office.js** — Excel JavaScript API
- **Vanilla JS** — no build step
- **Tailwind CSS** — styling
- **Static hosting** — GitHub Pages

## Built by

**Mohammed Zumar Ali Hassan**
MS Supply Chain Management (STEM), UT Dallas
🔗 [linkedin.com/in/zumarali15](https://linkedin.com/in/zumarali15)
📧 mohammedzumarali.hassan@utdallas.edu

**Full Should Cost AI tool:** [zumaralihassan-collab.github.io/Zumar-Should-Cost-Tool](https://zumaralihassan-collab.github.io/Zumar-Should-Cost-Tool/)
